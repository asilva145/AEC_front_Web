import React from 'react';
import {Accueil} from './Accueil'


function App() {

  return (
    
    <Accueil></Accueil>
   
  );
}
export default App;


  